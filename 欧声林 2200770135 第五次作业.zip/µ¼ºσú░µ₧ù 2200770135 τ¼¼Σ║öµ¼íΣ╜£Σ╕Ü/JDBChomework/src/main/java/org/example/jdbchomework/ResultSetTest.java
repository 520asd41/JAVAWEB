package org.example.jdbchomework;

import java.sql.*;

public class ResultSetTest {
    public static void main(String[] args) {
        String url = "jdbc:mysql://localhost:3306/teacher";
        String user = "root";
        String password = "123456";
        String sql = "SELECT * FROM teacher";
        try (Connection conn = DriverManager.getConnection(url, user, password);
             Statement stmt = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
             ResultSet rs = stmt.executeQuery(sql)) {

            // 移动到结果集的最后一行
            if (rs.last()) {
                // 移动到倒数第二条数据
                if (rs.previous()) {
                    // 输出倒数第二条数据
                    System.out.println("倒数第二条数据:");
                    System.out.println("ID: " + rs.getInt("id"));
                    System.out.println("Name: " + rs.getString("name"));
                    System.out.println("Course: " + rs.getString("course"));
                    System.out.println("Birthday: " + rs.getDate("birthday"));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
