package org.example.jdbchomework;

import java.sql.*;

public class SelectTest {
    public static void main(String[] args) {

        String url = "jdbc:mysql://localhost:3306/teacher";
        String user = "root";
        String password = "123456";
        String sql = "SELECT * FROM teacher WHERE id = ? ";

        try (Connection conn = DriverManager.getConnection(url, user, password);
             PreparedStatement ps = conn.prepareStatement(sql);
        ) {
            // 设置参数
            ps.setInt(1, 1);
            // 执行查询
            try (ResultSet rs = ps.executeQuery()) {
                // 输出查询结果
                while (rs.next()) {
                    System.out.println("ID: " + rs.getInt("id") + ", Name: " + rs.getString("name") + ", Course: " + rs.getString("course") + ", Birthday: " + rs.getDate("birthday"));
                }
            }catch (SQLException e) {
                e.printStackTrace();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
