package org.example.jdbchomework;

import java.sql.*;

public class PreparedStatementTest {
    public static void main(String[] args) {
        String url = "jdbc:mysql://localhost:3306/teacher";
        String user = "root";
        String password = "123456";
        // 批量插入数据
        String sql = "INSERT INTO teacher(id, name, course, birthday) VALUES(?, ?, ?, ?)";

        try (Connection conn = DriverManager.getConnection(url, user, password);) {
            conn.setAutoCommit(false);
            try (PreparedStatement ps = conn.prepareStatement(sql);) {
                // 设置参数
                for (int i = 1; i <= 500; i++) {
                    ps.setInt(1,i);
                    ps.setString(2, "Teacher " + i);
                    ps.setString(3, "Course " + i);
                    ps.setDate(4, new java.sql.Date(System.currentTimeMillis()));
                    // 添加到批处理
                    ps.addBatch();
                    if (i % 100 == 0) { // 每100条记录执行一次批处理
                        ps.executeBatch();
                        ps.clearBatch();
                    }
                }
                ps.executeBatch();
                conn.commit();
                System.out.println("完成批量插入数据");
            } catch (SQLException e) {
                conn.rollback();
                e.printStackTrace();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
