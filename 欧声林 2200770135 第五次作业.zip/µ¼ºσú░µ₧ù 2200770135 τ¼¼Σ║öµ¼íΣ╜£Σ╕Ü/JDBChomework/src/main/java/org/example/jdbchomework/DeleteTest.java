package org.example.jdbchomework;

import java.sql.*;

public class DeleteTest {
    public static void main(String[] args) {

        String url = "jdbc:mysql://localhost:3306/teacher";
        String user = "root";
        String password = "123456";
        // 删除名字为诸葛亮的老师
        String sql = "DELETE FROM  teacher WHERE name = ?";

        try (Connection conn = DriverManager.getConnection(url, user, password);) {
            conn.setAutoCommit(false);
            try (PreparedStatement ps = conn.prepareStatement(sql);) {
                // 设置参数
                ps.setString(1, "诸葛亮");
                // 执行删除
                ps.executeUpdate();
                conn.commit();
            } catch (SQLException e) {
                conn.rollback();
                e.printStackTrace();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
