package org.example.jdbchomework;
import java.sql.*;

public class InsertTest {
    public static void main(String[] args) {

        String url = "jdbc:mysql://localhost:3306/teacher";
        String user = "root";
        String password = "123456";
        // 插入数据 id=1, name=诸葛清, course=语文, birthday=1999-11-10
        String sql = "INSERT INTO teacher (id,name,course,birthday) VALUES (?,?,?,?)";

        try (Connection conn = DriverManager.getConnection(url, user, password);) {
            conn.setAutoCommit(false);
            try (PreparedStatement ps = conn.prepareStatement(sql);) {
                // 设置参数
                ps.setInt(1,1);
                ps.setString(2, "诸葛清");
                ps.setString(3, "语文");
                java.sql.Date birthday = new java.sql.Date(1999-1900, 11, 10);
                ps.setDate(4,birthday );
                // 执行插入
                ps.executeUpdate();
                conn.commit();
            } catch (SQLException e) {
                conn.rollback();
                e.printStackTrace();
            } finally {
                conn.setAutoCommit(true);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
